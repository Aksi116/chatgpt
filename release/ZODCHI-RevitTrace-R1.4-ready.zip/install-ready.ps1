param()
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $here 'Payload\ZODCHI.RevitTrace'
$addinBase = Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2025'
$installDir = Join-Path $addinBase 'ZODCHI.RevitTrace'
$manifestPath = Join-Path $addinBase 'ZODCHI.RevitTrace.addin'

if (Get-Process Revit -ErrorAction SilentlyContinue) {
    throw 'Close Revit before installing ZODCHI RevitTrace.'
}
if (-not (Test-Path (Join-Path $payload 'ZODCHI.RevitTrace.Addin.dll'))) {
    throw 'Payload is incomplete.'
}

New-Item -ItemType Directory -Force -Path $addinBase | Out-Null
Remove-Item $installDir -Recurse -Force -ErrorAction SilentlyContinue
Copy-Item $payload $installDir -Recurse -Force

$assembly = Join-Path $installDir 'ZODCHI.RevitTrace.Addin.dll'
$xml = @"
<?xml version="1.0" encoding="utf-8" standalone="no"?>
<RevitAddIns>
  <AddIn Type="Application">
    <Name>ZODCHI RevitTrace</Name>
    <Assembly>$assembly</Assembly>
    <AddInId>29F3222B-0C42-469E-9A2C-BC97D723EA7B</AddInId>
    <FullClassName>ZODCHI.RevitTrace.Addin.RevitTraceApplication</FullClassName>
    <VendorId>ZODCHI</VendorId>
    <VendorDescription>ZODCHI Research - observable Revit workflow recorder</VendorDescription>
  </AddIn>
</RevitAddIns>
"@
Set-Content -LiteralPath $manifestPath -Value $xml -Encoding UTF8

$settingsDir = Join-Path $env:APPDATA 'ZODCHI\RevitTrace'
New-Item -ItemType Directory -Force -Path $settingsDir | Out-Null

Write-Host ''
Write-Host 'ZODCHI RevitTrace installed.' -ForegroundColor Green
Write-Host "Manifest: $manifestPath"
Write-Host "Add-in:   $installDir"
Write-Host "Start Revit 2025 and open the ZODCHI Research ribbon tab."
