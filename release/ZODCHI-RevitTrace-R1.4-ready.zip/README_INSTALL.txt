ZODCHI RevitTrace R1.4 - READY BUILD FOR REVIT 2025

INSTALL:
1. Close Revit 2025.
2. Double-click INSTALL.cmd.
3. Start Revit 2025.
4. Open ribbon tab "ZODCHI Research".
5. Press "Start Capture".

No build, Revit path selection, Python, Visual Studio or Revit SDK is required.

INSTALL TARGET:
%APPDATA%\Autodesk\Revit\Addins\2025\ZODCHI.RevitTrace.addin
%APPDATA%\Autodesk\Revit\Addins\2025\ZODCHI.RevitTrace\

This package does NOT contain Autodesk RevitAPI.dll/RevitAPIUI.dll.
The recorder uses the Revit API assemblies loaded by Revit.
