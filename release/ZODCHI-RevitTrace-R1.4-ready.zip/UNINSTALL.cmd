@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$b=Join-Path $env:APPDATA 'Autodesk\Revit\Addins\2025'; Remove-Item (Join-Path $b 'ZODCHI.RevitTrace.addin') -Force -ErrorAction SilentlyContinue; Remove-Item (Join-Path $b 'ZODCHI.RevitTrace') -Recurse -Force -ErrorAction SilentlyContinue; Write-Host 'ZODCHI RevitTrace removed.'"
pause
